// Lightbox extension, http://github.com/schulle4u/yellow-extensions-schulle4u/tree/main/lightbox

var initLightboxFromDOM = function() {

    const tobii = new Tobii();
};

window.addEventListener("DOMContentLoaded", initLightboxFromDOM, false);